from utils.exception import user_not_found
from utils.status_codes import SUCCESS,CREATED

users = []

def get_all_users():
    return users

def get_user(user_id:int):
    for user in users:
        if user["id"]== user_id:
            return user
    raise user_not_found()

def create_user(user:dict):
    users.append(user)
    return {"msg":"user created"},CREATED

def update_user(user_id:int,updated_user:dict):
    for index,user in enumerate(users):
        if user["id"] == user_id:
            users[index] = updated_user
            return {"msg":"user updated"}, SUCCESS
    raise user_not_found()  

def delete_user(user_id:int):
    for user in users:
        if user["id"] == user_id:
            users.remove(user)
            return {"msg":"user deleted"},SUCCESS
    raise user_not_found()    
