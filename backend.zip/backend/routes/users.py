from fastapi import APIRouter
from controllers.userControllers import (
    get_all_users,
    get_user,
    create_user,
    update_user,
    delete_user
)
from utils.routes import USER_ROUTES

router = APIRouter(prefix=USER_ROUTES)


@router.get("/")
def read_users():
    return get_all_users()

@router.get("/{user_id}")
def read_user(user_id: int):
    return get_user(user_id)


@router.post("/")
def add_user(user: dict):
    return create_user(user)


@router.put("/{user_id}")
def update(user_id: int, user: dict):
    return update_user(user_id, user)


@router.delete("/{user_id}")
def delete(user_id: int):
    return delete_user(user_id)