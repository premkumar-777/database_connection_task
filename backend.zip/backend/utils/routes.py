# If later you want /api/v1/users → change only here
# this help to chage easily later
USER_ROUTES = "/users"
