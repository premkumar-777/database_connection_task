from fastapi import HTTPException
from utils.status_codes import NOT_FOUND,BAD_REQUEST


def user_not_found():
    return HTTPException(
        status_code = NOT_FOUND,
        details = "user not found"
    )

def bad_request():
    return HTTPException(
        status_code=BAD_REQUEST,
        details="Bad request"
    )