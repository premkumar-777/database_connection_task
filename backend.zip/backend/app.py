from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from db.database import SessionLocal, engine
from models.usermodels import Base
from models.usermodels import Base, User
from schemas.user_schema import UserCreate
app = FastAPI()
Base.metadata.create_all(bind=engine)


#dependency (DB session)
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()    
        
# Endpoint for add user
@app.post("/users")
def add_user(user:UserCreate, db: Session = Depends(get_db)):
    new_user = User(
        name=user.name,
        email=user.email,
        role=user.role
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return {"message": "user added", "user": new_user.id}
    
# endpoint for get user
@app.get("/users")
def get_users(db:Session = Depends(get_db)):
    users = db.query(User).all()
    return users

#get specific user
@app.get("/users/{user_id}")
def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        return {"error":"User Not Found"}
    return user

#delete specific user
@app.delete("/users/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        return {"message":"User Not found"}

    db.delete(user)
    db.commit()

    return {"message": "User deleted sucessfully","user":user.name}

#update user details
@app.put("/users/{user_id}")
def update_user(user_id:int,name:str,email:str,role:str,db:Session=Depends(get_db)):
    user=db.query(User).filter(User.id==user_id).first()

    if not user:
        return {"error":"User not found"}
    
    user.name = name
    user.email = email
    user.role = role
    db.commit()
    db.refresh(user)
    return {"message": "user Updated"}

@app.get("/")
def test_db():
    return {"message": "DB CONNECTED SUCCESSFULLY"}
